package FuncionariosBasico;

public class Funcionario {
    private String nome;
    private String cargo;
    private double salario;

    public Funcionario(String nome, String cargo, double salario){
        setNome(nome);
        setCargo(cargo);
        setSalario(salario);
    }

    public String getNome(){
        return nome;
    }

    public void setNome(String nome){
        this.nome = nome;
    }

    public String getCargo(){
        return cargo;
    }

    public void setCargo(String cargo){
        this.cargo = cargo;
    }

    public double getSalario(){
        return salario;
    }

    public void setSalario(double salario){
        this.salario = salario;
    }

    public void aumentarSalario(double percentual){
        salario = salario + (salario * percentual / 100);
    }

    public double calcularSalarioAnual(){
        return salario * 12;
    }

    public void exibirDados(){
        System.out.println("Nome: " + nome);
        System.out.println("Cargo: " + cargo);
        System.out.println("Salario: R$ " + salario);
        System.out.println("Salario anual: R$ " + calcularSalarioAnual());
    }
}
