package Main;

import Caixa.CaixaEletronico;
import Vendas.Vendedor;
import FuncionariosBasico.Funcionario;
import FuncionariosHeranca.Gerente;
import Contas.ContaCorrente;
import Contas.ContaPoupanca;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int opcao;

        do {
            System.out.println("===== TRABALHO N1 - TECNICAS DE PROGRAMACAO =====");
            System.out.println("1 - Caixa Eletronico");
            System.out.println("2 - Sistema de Vendas");
            System.out.println("3 - Sistema de Funcionarios");
            System.out.println("4 - Funcionarios com Heranca");
            System.out.println("5 - Sistema de Contas Bancarias");
            System.out.println("6 - Sair");
            System.out.print("Opcao: ");
            opcao = scanner.nextInt();

            System.out.println();

            switch (opcao) {
                case 1:
                    executarCaixaEletronico(scanner);
                    break;

                case 2:
                    executarSistemaVendas(scanner);
                    break;

                case 3:
                    executarSistemaFuncionarios();
                    break;

                case 4:
                    executarFuncionariosHeranca();
                    break;

                case 5:
                    executarContasBancarias();
                    break;

                case 6:
                    System.out.println("Encerrando...");
                    break;

                default:
                    System.out.println("Opcao invalida. Digite novamente.");
                    break;
            }

            System.out.println();

        } while (opcao != 6);

        scanner.close();
    }

    private static void executarCaixaEletronico(Scanner scanner){
        CaixaEletronico caixa = new CaixaEletronico();

        System.out.print("Valor do saque: ");
        int valor = scanner.nextInt();

        System.out.println();
        caixa.realizarSaque(valor);
    }

    private static void executarSistemaVendas(Scanner scanner){
        Vendedor vendedor = new Vendedor();

        System.out.print("Quantidade de vendas: ");
        int quantidade = scanner.nextInt();

        float[] vendas = new float[quantidade];

        for (int i = 0; i < quantidade; i++){
            System.out.print("Valor da venda " + (i + 1) + ": ");
            vendas[i] = scanner.nextFloat();
        }

        vendedor.registrarVendas(vendas);

        System.out.println();
        vendedor.mostrarResultados();
    }

    private static void executarSistemaFuncionarios(){
        Funcionario f1 = new Funcionario("Ana", "Analista", 3000);
        Funcionario f2 = new Funcionario("Bruno", "Assistente", 2000);
        Funcionario f3 = new Funcionario("Carla", "Gerente", 5000);
        Funcionario f4 = new Funcionario("Diego", "Estagiario", 1200);
        Funcionario f5 = new Funcionario("Elisa", "Coordenadora", 4000);

        f1.aumentarSalario(10);
        f2.aumentarSalario(5);
        f3.aumentarSalario(8);
        f4.aumentarSalario(15);
        f5.aumentarSalario(7);

        f1.exibirDados();
        System.out.println();
        f2.exibirDados();
        System.out.println();
        f3.exibirDados();
        System.out.println();
        f4.exibirDados();
        System.out.println();
        f5.exibirDados();
    }

    private static void executarFuncionariosHeranca(){
        FuncionariosHeranca.Funcionario funcionario = new FuncionariosHeranca.Funcionario("Joao", 2000);
        Gerente gerente = new Gerente("Marcos", 3000);
        FuncionariosHeranca.Vendedor vendedor = new FuncionariosHeranca.Vendedor("Paula", 1500, 4000);

        funcionario.exibirDados();
        System.out.println();
        gerente.exibirDados();
        System.out.println();
        vendedor.exibirDados();
    }

    private static void executarContasBancarias(){
        ContaCorrente contaCorrente = new ContaCorrente(1, "Rafael", 1000, 15);
        ContaPoupanca contaPoupanca = new ContaPoupanca(2, "Julia", 1000, 0.02);

        contaCorrente.depositar(500);
        contaCorrente.sacar(200);

        contaPoupanca.depositar(300);

        System.out.println("Conta Corrente:");
        contaCorrente.mostrarDados();

        System.out.println();

        System.out.println("Conta Poupanca:");
        contaPoupanca.mostrarDados();
    }
}
