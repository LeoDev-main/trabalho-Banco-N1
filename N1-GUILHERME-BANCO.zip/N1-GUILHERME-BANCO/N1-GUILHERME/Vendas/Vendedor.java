package Vendas;

public class Vendedor {
    private float[] vendas;

    public void registrarVendas(float[] vendas){
        this.vendas = vendas;
    }

    public float calcularTotal(){
        float total = 0;

        for (int i = 0; i < vendas.length; i++){
            total = total + vendas[i];
        }

        return total;
    }

    public float calcularMaiorVenda(){
        float maior = vendas[0];

        for (int i = 1; i < vendas.length; i++){
            if (vendas[i] > maior){
                maior = vendas[i];
            }
        }

        return maior;
    }

    public float calcularMenorVenda(){
        float menor = vendas[0];

        for (int i = 1; i < vendas.length; i++){
            if (vendas[i] < menor){
                menor = vendas[i];
            }
        }

        return menor;
    }

    public float calcularMedia(){
        return calcularTotal() / vendas.length;
    }

    public int contarVendasAcimaDe(float valor){
        int contador = 0;

        for (int i = 0; i < vendas.length; i++){
            if (vendas[i] > valor){
                contador++;
            }
        }

        return contador;
    }

    public float calcularComissao(){
        float total = calcularTotal();
        float comissao;

        if (total <= 1000){
            comissao = total * 0.03f;
        }else if (total <= 5000){
            comissao = total * 0.05f;
        }else{
            comissao = total * 0.08f;
        }

        return comissao;
    }

    public void mostrarResultados(){
        System.out.println("Valor total vendido: R$ " + calcularTotal());
        System.out.println("Maior venda: R$ " + calcularMaiorVenda());
        System.out.println("Menor venda: R$ " + calcularMenorVenda());
        System.out.println("Media das vendas: R$ " + calcularMedia());
        System.out.println("Vendas acima de R$ 500: " + contarVendasAcimaDe(500));
        System.out.println("Comissao do vendedor: R$ " + calcularComissao());
    }
}
