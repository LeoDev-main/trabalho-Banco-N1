package Contas;

public class ContaPoupanca extends Conta {
    private double percentualRendimento;

    public ContaPoupanca(int numero, String titular, double saldo, double percentualRendimento){
        super(numero, titular, saldo);
        setPercentualRendimento(percentualRendimento);
    }

    public double getPercentualRendimento(){
        return percentualRendimento;
    }

    public void setPercentualRendimento(double percentualRendimento){
        this.percentualRendimento = percentualRendimento;
    }

    @Override
    public double calcularSaldo(){
        //rendimento somado ao saldo (saldo + saldo * percentual)
        return getSaldo() + (getSaldo() * percentualRendimento);
    }
}
