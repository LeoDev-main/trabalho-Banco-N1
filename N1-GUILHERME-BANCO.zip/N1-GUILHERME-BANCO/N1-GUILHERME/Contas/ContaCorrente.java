package Contas;

public class ContaCorrente extends Conta {
    private double taxaManutencao;

    public ContaCorrente(int numero, String titular, double saldo, double taxaManutencao){
        super(numero, titular, saldo);
        setTaxaManutencao(taxaManutencao);
    }

    public double getTaxaManutencao(){
        return taxaManutencao;
    }

    public void setTaxaManutencao(double taxaManutencao){
        this.taxaManutencao = taxaManutencao;
    }

    @Override
    public double calcularSaldo(){
        return getSaldo() - taxaManutencao;
    }
}
