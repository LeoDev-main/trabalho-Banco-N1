package Caixa;

public class CaixaEletronico {
    private int[] notasDisponiveis = {200, 100, 50, 20, 10, 5, 2};

    public void realizarSaque(int valor){
        System.out.println("Notas:");

        for (int i = 0; i < notasDisponiveis.length; i++){
            int nota = notasDisponiveis[i];

            if (valor >= nota){
                int quantidade = valor / nota;
                valor = valor % nota;

                System.out.println(quantidade + " x R$ " + nota);
            }
        }
    }
}
