package FuncionariosHeranca;

public class Vendedor extends Funcionario {
    private double totalVendas;

    public Vendedor(String nome, double salarioBase, double totalVendas){
        super(nome, salarioBase);
        setTotalVendas(totalVendas);
    }

    public double getTotalVendas(){
        return totalVendas;
    }

    public void setTotalVendas(double totalVendas){
        this.totalVendas = totalVendas;
    }

    @Override
    public double calcularSalario(){
        return getSalarioBase() + (totalVendas * 0.10);
    }
}
